﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello group Fri2,Java1");
            Console.WriteLine("Hello everyone. My name is Gopi varas Marisetty (n9778357).");
            Console.WriteLine("Hello everyone. My name is Gurjeet Singh(n9600299)");
            Console.WriteLine("Hello. My name is Tuyen, student ID 9861998. Nice to meet you guys");
            Console.WriteLine("Hello everyone. My name is Karry (n9916113)");
            Console.WriteLine("Hello everyone. My name is Jonno (n9599291). my chinese name is YIXI zhou");
            Console.ReadKey();
        }
    }
}
